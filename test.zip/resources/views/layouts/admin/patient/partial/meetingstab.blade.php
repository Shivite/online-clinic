<div class="tab-pane" id="meetings">

    <div class="post">
        @include('layouts.admin.doctor.partial.doctopatientmeeting')


    </div>

    <div class="post clearfix">
    </div>

</div>