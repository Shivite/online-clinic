<div class="tab-pane" id="reports">
    <!-- Post -->
    <div class="post">
        <!-- /*pass patient elequent to file*/ -->
        @include('layouts.admin.patient.partial.patientreports')
    </div>
    <!-- /.post -->

    <!-- Post -->
    <div class="post clearfix">
    </div>
    <!-- /.post -->
</div>
<!-- /.tab-pane -->