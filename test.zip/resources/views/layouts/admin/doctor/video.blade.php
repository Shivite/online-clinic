<iframe
    src="https://tokbox.com/embed/embed/ot-embed.js?embedId=2ac73469-77f1-42c0-b68d-a496a6cfd988&room=DEFAULT_ROOM&iframe=true"
    width=800 height=640 scrolling="auto" allow="microphone; camera">
</iframe>